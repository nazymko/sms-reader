package org.nazymko;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Andrew Nazymko
 */
public class SmsReader {

    List<Sms> open(String file) throws IOException {
        List<Sms> list = new ArrayList();
        final int[] index = {0};
        try (BufferedReader reader = new BufferedReader(new FileReader(new File(file)))) {
            reader.lines().forEachOrdered(line -> list.add(new Sms(LocalDateTime.now().minus((long) ((++index[0]) * 100_000), ChronoUnit.SECONDS), line)));
        }
        return list;
    }
}
