package org.nazymko.utils;

import java.util.regex.Pattern;

/**
 * Created by Andrew Nazymko
 */
public class MoneyParser {

    public static final int SCALE = 100;
    private static final Pattern PATTERN = Pattern.compile("\\d*.{0,1}\\d{1,2}");

    public static boolean isDigits(String text) {
        return PATTERN.matcher(text).matches();

    }

    public static Long normalize(String text) {
        if (text.contains(".")) {
            String[] strings = text.split("\\.");

            Long big = Long.valueOf(strings[0]);
            Long small = Long.valueOf(strings[1]);

            if (small <= 100) {
                return big * SCALE + small;
            } else {
                throw new IllegalArgumentException(text);
            }
        } else {
            return Long.valueOf(text) * SCALE;
        }
    }
}
