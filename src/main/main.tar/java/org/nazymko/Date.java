package org.nazymko;

import java.time.LocalDateTime;

/**
 * Created by Andrew Nazymko
 */
public class Date {
    LocalDateTime dateTime;
}
