package org.nazymko;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main {

    public static void main(String[] args) throws IOException {

        List<Sms> slsList = new SmsReader().open("sms.log");
        Collections.sort(slsList, (first, second) -> first.time.isEqual(second.time) ? 0 : first.time.isBefore(second.time) ? -1 : 1);

        List<History> histories = new ArrayList<>();
        for (Sms sms : slsList) {
            histories.add(History.of(sms));
        }
        System.out.println("histories = " + histories);


    }
}
